clear,clc
size=[50,70];
% A = ones(size(1),size(2));
% y = ones(size(1),1);
A = rand(size(1),size(2));
y = rand(size(1),1);
% for i=1:size(1)
%     A(i,:)=A(i,:)*i;
%     y(i)=y(i)*(10-i);
% end
w=[];
lambda = 1e-3;
arg.x0 = ones(size(2),1);
arg.solver = 'ista';
%arg.eta = [];
arg.eta = (rand(size(2),1))/10;
arg.maxIter = 50;
arg.tolX = 1e-4;

[x,fval,ite] = l1ls_box_ista(A,y,w,lambda,arg);