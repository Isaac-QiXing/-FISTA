function [x,fval,ite_s] = l1ls_box_ista(A,y,w,lambda,arg)
% solve the l1-regularized least squares with box-constraints by ISTA (or
% FISTA)
%   This function  solves
%       min_{x} 1/2||Ax-y||_2^2 +  lambda* sum_i |x_i * eta_i| 
%       s.t.    w_i*|x_i| <= 1,
%   where w_i>=0 is scale factor, i = 1,...,n�� eta_i >=0, 
%   lambda>0 is a given parameter. 
% Inputs:
%	A           A m-by-n matrix, with m<=n;
%	y           vector of length m.
%   w           the scale factors. 
%   lambda      a given postive scalar;  
%   arg         Optional, a structue with following fields:
%   .x0: a column vector, indicating the initial point;
%   .solver: 
%      'ista': employ backward iterative shrinkage thresholding algorithm;
%      'fista': employ fast backward iterative shrinkage thresholding
%          algorithm; default value;
%   .eta: optional, a  vector with the same size as arg.x0, each coordinate is nonnegative; 
%        default value [], arg.eta would set as [1,1,...1]';   
%   .maxIter: maximum iteration number, default 1E4;
%   .tolX: termination tolerence of solution x; default 1E-4;
% Outputs:
%  x: optimal solution;
%  fval: ojective function value;
%  ite_s: a struct consisting of the iteration infromation:
%     .exitflag: 
%       1: succeed to solve;
%       -1: exceeds the maximum iteration number;
%     .iterations: iteration number;
%     .fun_num: number of function evaluations;
%     .grad_num: number of gradient evaluations;
% Versions: 
% * 2019.3.7 generalize the l1 norm as the weighted l1 norm
%    add a parameter 
%       arg.eta
% * 2013.12 first version. 

A_trans = A';
fun = @(x) (0.5*norm(A*x-y)^2);
grad = @(x) A_trans*(A*x-y);
dim = size(A,2);
arg.box = w;

% if ~isfield(arg,'eta') && isempty(arg.eta)
%     arg.eta = ones(dim,1);
% end
[x,fval,ite_s] = ista(fun,grad,lambda,dim,arg);

end