function y = proj_box(x,w,kappa)
% projection of a vector onto a ``box'': {x | w_i*|x_i| <= kappa }
% Inputs:
%  x: a vector;
%  w: a nonnegative vector with the same size as x;
%  kappa: Optional, a positive scalar, default 1;
% Outputs:
%  y: the projection point of x, a vector with the same size as x

if nargin<=2
    kappa = 1.0;
end

y = x;
ind = w>0;
if nnz(ind)>0
    w(ind) = kappa./w(ind);
    y(ind) = max(min(x(ind),w(ind)),-w(ind));   
end

end